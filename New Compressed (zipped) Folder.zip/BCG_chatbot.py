import pandas as pd

# Load and clean data
def load_data(filepath):
    df = pd.read_csv(filepath)
    
    # Clean numeric columns (add more columns as needed)
    numeric_columns = ['Total Revenue', 'Operating Income', 'Net Income']  # Example columns
    for col in numeric_columns:
        if col in df.columns:
            df[col] = df[col].replace({'\$': '', ',': ''}, regex=True).astype(float)
    return df

# Financial calculations
def calculate_total(df, column):
    return df[column].sum()

def calculate_average(df, column):
    return df[column].mean()

def find_max(df, column):
    return df[column].max()

def find_min(df, column):
    return df[column].min()

# Interactive query processing
def process_query(df, query):
    query = query.lower()
    columns = {
        'revenue': 'Total Revenue',
        'income': 'Operating Income',
        'net income': 'Net Income'
    }
    
    # Detect column in query
    target_column = None
    for key, value in columns.items():
        if key in query:
            target_column = value
            break
    
    if not target_column:
        return "Please specify a valid financial metric (revenue, income, net income)"
    
    # Process calculation type
    if 'total' in query:
        result = calculate_total(df, target_column)
        return f"Total {target_column}: ${result:,.2f}"
    elif 'average' in query:
        result = calculate_average(df, target_column)
        return f"Average {target_column}: ${result:,.2f}"
    elif 'maximum' in query or 'highest' in query:
        result = find_max(df, target_column)
        return f"Maximum {target_column}: ${result:,.2f}"
    elif 'minimum' in query or 'lowest' in query:
        result = find_min(df, target_column)
        return f"Minimum {target_column}: ${result:,.2f}"
    else:
        return "Could not understand query. Try:\n- Total revenue\n- Average income\n- Maximum net income"

# Main program
if __name__ == "__main__":
    df = load_data("financial_data.csv")
    print("Financial Analysis System")
    print("Available metrics: Revenue, Operating Income, Net Income")
    print("Available commands: total, average, maximum, minimum")
    print("Type 'exit' to quit\n")
    
    while True:
        query = input("\nEnter your query: ").strip()
        if query.lower() == 'exit':
            break
        response = process_query(df, query)
        print(f"\n{response}")